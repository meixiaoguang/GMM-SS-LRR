function [endmembers,options,I,Y,R_gt,A_gt,names] = prepare_supervised_unmixingMei(dataset,options,Results_segment,num_segment,mapping)
%PREPARE_SUPERVISED_UNMIXING Summary of this function goes here
%   Detailed explanation goes here
if nargin >2
    options = [];
end
switch dataset
    case '00'
        load('toy_image_end_var_3_C_try_5.mat');
        endmembers=[];
        
    case '001'
        load('muufl_gulfport_jqw.mat');
        endmembers=[];
         M_ori=5;
    case '002'
        load('Urban_corrected_M=5.mat');
        % load('Urban_corrected_try.mat');
        E_gt=M;
        
    case '003'
        load('Synthenic_new.mat');
        E_gt=E;
        endmembers=[];
        M_ori=5;
    case '004'
       load('SalinasA_jqw.mat');
       A_gt=double(A_gt);
       M_ori=6;
end
if isstruct(options)
    arg_set = fieldnames(options);
    for i = 1:length(arg_set)
        eval([arg_set{i},'=options.',arg_set{i},';']);
    end
end
[Y,A_gt,rows,cols] = reshape_hsi(I,A_gt);
[N,M] = size(A_gt);
[N,B] = size(Y);

        
switch dataset
    case {'0','01','7','71'} % pure_spectra is a cell array of endmember spectra
        endmembers = pure_spectra;
    case {'003'} % slice E_gt to get the endmember spectra
        endmembers = cell(1,M);
        for j = 1:M
            endmembers{j} = reshape(E_gt(j,:,:),B,N)';
        end
    otherwise % A_gt uses 1 to mark pure pixels
        endmembers = cell(1,M);
        for j = 1:M
            X = Y(A_gt(:,j)==1, :);
            endmembers{j} = X;
        end
end



R_gt = zeros(M,B);
for j = 1:M
    R_gt(j,:) = mean(endmembers{j});
end
options = insert_param_when_absent(options, 'reduced_dim', 10);
options = insert_param_when_absent(options, 'max_num_comp', 4);
options = insert_param_when_absent(options, 'show_fig', 0);

options = insert_param_when_absent(options, 'fix_w_k', 1);
options = insert_param_when_absent(options, 'fix_mu_jk', 1);
options = insert_param_when_absent(options, 'fix_sigma_jk', 1);

options = insert_param_when_absent(options, 'project_mapping', mapping);
options = insert_param_when_absent(options, 'max_num_comp', 5);
M = length(endmembers);

A = [];
X = [];
for j = 1:M
    N1 = size(endmembers{j},1);
    X1 = gmm_project(endmembers{j}, mapping);
    A1 = zeros(N1,M);
    A1(:,j) = 1;
    A = cat(1,A,A1);
    X = cat(1,X,X1);
end

sizes = [N, M];
[K,w_jk,mu_jk,sigma_jk,A1] = estimate_num_comp(X, A, sizes, 0, options.max_num_comp, options);

options.w_jk = w_jk;
options.mu_jk = mu_jk;
options.sigma_jk = sigma_jk;
options.K = K;
options.show_approx=1;
options = insert_param_when_absent(options, 'beta1', 0);
options = insert_param_when_absent(options, 'beta2', 0);


end

