function [L,KL,H] = calc_Laplacians(I,options, eta, beta1, beta2, M,Results_segment,num_segment)
 [R,C]=size(Results_segment.index{num_segment});
[rows,cols,B] = size(I);
N = rows * cols;
I=reshape(I,[N,B]);
I= gmm_project(I, options.project_mapping);
I=reshape(I,[rows,cols,10]);
[W,Neighbors] = image2graph(I,eta,1e-9);%%Build a W matrix between the top, bottom, left, and right points of the current point
W_new=Sparse_new(W,Results_segment,num_segment);

D = diag(sum(W_new,2));    
L = D - W_new;
L = sparse(L);

KL = L - beta2/beta1 * speye(C);
W = ones(M,M);
D = diag(sum(W,2));
H = D - W;