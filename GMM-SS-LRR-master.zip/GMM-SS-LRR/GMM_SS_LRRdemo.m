function [ output_args ] =GMM_SS_LRRdemo( input_args )
% Summary of this function goes here
%   Detailed explanation goes here
close all;
clc;

dataset = '003';
switch dataset
    case '001'
        load('muufl_gulfport_jqw.mat');
        segnum=5;
        is_real_dataset=1;
    case '002'
       load('Urban_corrected_M=5.mat');
        segnum=5;
    case '003'
        load('Synthenic_new.mat');
        segnum=5;
        is_real_dataset=0;
    case '004'
        load('SalinasA_jqw.mat');   
 segnum=5;
 is_real_dataset=1;
end
[rows,cols,B] = size(I);
[Y,A_gt,rows,cols] = reshape_hsi(I,A_gt);
reduced_dim=10;
[Y, mapping] = pca(Y, reduced_dim);
[~,M]=size(A_gt);
I_org=I;
[rows,cols,B] = size(I);
I_org=I;
D = 0.01^2 * eye(B);
beta1 =0.1;
beta2 =0.1;
beta3=0.1;
options.show_fig = 1;
options.names = names;
options.D = D;
options.project_mode = 'image';
options.convergence_thresh = 0.0001;

%% 
disp('Entropy Rate Superpixel Segmentation');
[M1, N1, C1] = size(I);
p1 = 1; % number of principle components
[X_pca] = pca(reshape(I, M1*N1, C1), p1);
img = im2uint8(mat2gray(reshape(X_pca', M1, N1, p1)));
labels =mex_ers(double(img), segnum);
figure;
imshow(img,[]);
[height width] = size(img);
[bmap] = seg2bmap(labels,width,height);
bmapOnImg = img;
idx = find(bmap>0);
timg = img;
timg(idx) = 255;
bmapOnImg(:,:,2) = timg;
bmapOnImg(:,:,1) = img;
bmapOnImg(:,:,3) = img;
figure;
imshow(bmapOnImg,[]);
Results_segment = seg_im_class(I, labels);
Num=size(Results_segment.Y,2);

 %% Unmixing%%
for i=1:Num 
    I_temp = Results_segment.Y{1,i};
    num_segment=i;
     [endmembers,options,I,Y,R_gt,A_gt,names] = prepare_supervised_unmixing(dataset,options,Results_segment,num_segment,mapping);
         [rows,cols,B] = size(I);
    D = 0.001^2 * eye(B);
    options.beta1 =beta1;
    options.beta2 =beta2;
    options.beta3=beta3;
    options.show_fig= 1;
    options.names = names;
    options.D = D;
    options.project_mode = 'image';
    options.convergence_thresh = 0.0001;
    [A_temp,R_temp,w_jk,mu_jk,sigma_jk,extra_temp] = gmm_unmixing(I_temp,options,endmembers,I_org,Results_segment, num_segment);
A(Results_segment.index{i},:)=A_temp; 
end
         A_error=calc_abundance_error(A_gt,A,is_real_dataset);
          for i=1:M
         error_all(i)=calc_abundance_error(A_gt(:,i),A(:,i),is_real_dataset);
          end
         show_abundances(A,rows,cols,'',1,M);
    opts = struct('show_approx',1,'w_jk',{w_jk},'mu_jk',{mu_jk},'sigma_jk',...
        {sigma_jk},'legend_names',{{'GMM-SS-LRR'}});
      hist_end_var(Y,A_gt,names,1,opts);